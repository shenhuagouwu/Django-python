﻿一、Django的基本命令
'''
django-admin   查看django是否安装成功
check                校验项目完整性
compilemessages
createcachetable
dbshell
diffsettings
dumpdata          把数据库数据导出到文件
flush
inspectdb
loaddata               把文件数据导入到数据库
makemessages
makemigrations     创建模型变更的迁移文件
migrate                 执行上一个命令创建的迁移文件
runserver               本地简易运行Django项目
sendtestemail
shell                       进入Django项目的Python Shell环境
showmigrations
sqlflush
sqlmigrate
sqlsequencereset
squashmigrations
startapp                    创建一个django应用
startproject               创建一个django项目
test                          执行Django用例测试
testserver
'''